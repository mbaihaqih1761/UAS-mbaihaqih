package com.example.uts_mp_mbaihaqih;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.lang.annotation.Target;

public class MainActivity extends AppCompatActivity {
    Button buttonbukasatu, buttonbukadua, buttonbukatiga, buttonbukaempat;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonbukasatu = (Button) findViewById(R.id.buttonbukasatu);
        buttonbukadua = (Button) findViewById(R.id.buttonbukadua);
        buttonbukatiga = (Button) findViewById(R.id.buttonbukatiga);
        buttonbukaempat = (Button) findViewById(R.id.buttonbukaempat);
        buttonbukasatu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Bukaactsatu = new Intent(getApplicationContext(), satuActivity.class);
                startActivity(Bukaactsatu);
            }
        });
        buttonbukadua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Bukaactdua = new Intent(getApplicationContext(), duaActivity.class);
                startActivity(Bukaactdua);
            }
        });
        buttonbukatiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Bukaacttiga = new Intent(getApplicationContext(), tigaActivity.class);
                startActivity(Bukaacttiga);
            }
        });
        buttonbukaempat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Bukaactempat = new Intent(getApplicationContext(), empatActivity.class);
                startActivity(Bukaactempat);
            }
        });
    }
}